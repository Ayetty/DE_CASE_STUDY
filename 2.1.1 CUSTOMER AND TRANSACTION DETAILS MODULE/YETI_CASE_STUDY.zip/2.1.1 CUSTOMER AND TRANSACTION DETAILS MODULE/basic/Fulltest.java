package basic;
import dao.TransactionDAOImpl;
import dao.CustomerDAOImpl;
import java.sql.SQLException;
import java.util.Scanner;


public class Fulltest {
public static void main(String[] args) throws SQLException{

			System.out.println("Welcome to Credit Card System (CCS) Application: ");
			System.out.println("Kindly enter your social security number:");
             Scanner Input = new Scanner (System.in);
                int ssn_1 = Input.nextInt();
                CustomerDAOImpl c1 = new CustomerDAOImpl();
                c1.checkSSN(ssn_1);
                if (!c1.checkSSN(ssn_1).next()) {
			System.out.println("Sorry this SSN is not found in our database");
}
            else
{
        System.out.println("Enter 1 for Customer details");
        System.out.println("Enter 2 for Transaction details");
 int userInput = Input.nextInt();

        if( userInput ==1){
            System.out.println("You are now in the CCS Application, Customer Details Module");
            System.out.println("Enter 1 to check existing account details");
            System.out.println("Enter 2 to modify existing account information");
            System.out.println("Enter 3 to generate monthly bill for a given month and year");
            System.out.println("Enter 4 to display transactions between two dates");
            System.out.println("Kindly proceed");

            int input_customer = Input.nextInt();
            if (input_customer == 1) {

                //System.out.println("Kindly enter your social security number:");
               // int ssn_2 = Input.nextInt();
     
 CustomerDAOImpl c2 = new CustomerDAOImpl();
                c2.checkAccount(ssn_1);
                }

            if (input_customer == 2) {
            	System.out.println("Enter 1 for change of address");
            	System.out.println("Enter 2 for change of name");
            	System.out.println("Enter 3 for other changes");
            	System.out.println("Kindly proceed");
            
            	int input_modify=Input.nextInt();
                  
            	 if (input_modify == 1) { 
            	//System.out.println("Kindly enter your social security number: ");
                //int ssn_2 = Input.nextInt();
                System.out.println("Kindly enter your new apartment number");
                String apt_no = Input.next();
                System.out.println("Kindly enter your new street name");
                String street_name = Input.next();
                System.out.println("Kindly enter your new city");
                String cust_city = Input.next();
                System.out.println("Kindly enter your new state");
                String cust_state = Input.next();
                System.out.println("Kindly enter your new zip code");
                String cust_zip =Input.next();
CustomerDAOImpl c2 = new CustomerDAOImpl();
                c2.modifyAccount(apt_no, street_name, cust_city, cust_state, cust_zip,ssn_1);
                }
              if (input_modify == 2) {
            	  //System.out.println("Kindly enter your social security number: ");
 			      //int ssn_3 = Input.nextInt();
 			     System.out.println("Kindly enter your new First Name");
                  String first_name = Input.next();
                  System.out.println("Kindly enter your new Middle Name");
                  String middle_name = Input.next();
                  System.out.println("Kindly enter your new Last Name");
                  String last_name = Input.nextLine();
CustomerDAOImpl c6 = new CustomerDAOImpl();
                  c6.modifyName( first_name, middle_name, last_name, ssn_1);
 			       }
        if (input_modify ==3) {
        	//System.out.println("Kindly enter your social security number: ");
        	//int ssn_4 = Input.nextInt();
        	System.out.println("Kindly enter your new phonenumber: ");
        	int cust_phone = Input.nextInt();
        	System.out.println("Kindly enter your new email address");
        	String email = Input.next();
CustomerDAOImpl c7 = new CustomerDAOImpl();
		c7.modifyOtherAccountDetails(cust_phone, email, ssn_1);
        	
        }
            }
            
  if (input_customer == 3) {
	  Scanner Input_3 = new Scanner(System.in);

                System.out.println("Kindly enter your credit card number: ");
                String credit_card_no = Input_3.nextLine();

                System.out.println("Kindly enter the month");
                int month =Input.nextInt();

                System.out.println("Kindly enter the year ");
                int year = Input.nextInt();

                CustomerDAOImpl c3 = new CustomerDAOImpl();
                c3.getMonthlyBill(credit_card_no,month,year);
                }
        
            if (input_customer == 4) {

                System.out.println("Welcome, proceed to check your transactions between dates");
                //System.out.println("ENTER SSN");
    	        //int ssn = Input.nextInt();
    	        System.out.println("ENTER START YEAR");
    	        int year1 = Input.nextInt();
    	        System.out.println("ENTER END YEAR");
    	        int year2 = Input.nextInt();
    	        System.out.println("ENTER START MONTH");
    	        int month1 = Input.nextInt();
    	        System.out.println("ENTER END MONTH");
    	        int month2 = Input.nextInt();
    	        System.out.println("ENTER START DAY");
    	        int day1 = Input.nextInt();
    	        System.out.println("ENTER END DAY");
    	        int day2 = Input.nextInt(); 
                CustomerDAOImpl c4 = new CustomerDAOImpl();
                    c4.checkTransactionsBetweenDates(year1, month1, day1, year2,month2,day2, ssn_1);
                }
              }
        if( userInput ==2) {
            System.out.println("Welcome, proceed to check your transaction details");
            System.out.println("Enter 1 to display the transactions for a given month and year by zipcode");
            System.out.println("Enter 2 to display the total number and total value of a transaction type");
            System.out.println("Enter 3 to display the total number and total value of transactions for branches in a given state");
            System.out.println("Please choose an option to continue");
            
            Scanner Input2 = new Scanner(System.in);
            int input_transaction = Input2.nextInt();
            if (input_transaction == 1) {

                Scanner Trans = new Scanner(System.in);
                //System.out.println("Kindly enter your credit card number:");
                //String credit_card_no = Trans.nextLine();

                System.out.println("Kindly enter your zipcode: ");
                String zip_code = Trans.nextLine();

                System.out.println("Kindly enter month: ");
                int month  = Input2.nextInt();

                System.out.println("Kindly enter year: ");
                int year = Input2.nextInt();

                TransactionDAOImpl t1 = new TransactionDAOImpl();
                t1.getTransactionsByZipcode(zip_code, month, year);
            }

            if (input_transaction == 2) {

                Scanner Trans2 = new Scanner(System.in);
                System.out.println("Kindly enter a transaction type, this is case sensitive: ");
                String transaction_type = Trans2.nextLine();

                TransactionDAOImpl t2 = new TransactionDAOImpl();
                t2.TotalTransactionNumberAndValue(transaction_type);

            }

            if (input_transaction == 3) {

                Scanner Trans3 = new Scanner(System.in);
                System.out.println("Kindly enter a state name: ");

                String state = Trans3.nextLine();
                TransactionDAOImpl t3 = new TransactionDAOImpl();
                t3.getTransactionByState(state);
Input.close();
}
            }
        }
}
}
            
            
        


        

    



