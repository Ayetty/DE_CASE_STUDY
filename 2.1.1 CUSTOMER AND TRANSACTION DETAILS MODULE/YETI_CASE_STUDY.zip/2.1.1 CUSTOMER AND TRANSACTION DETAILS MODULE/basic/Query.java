package basic;
public class Query {

    public static final String getTransactionsByZipCode =" select * from cdw_sapp_creditcard "+
            " inner join cdw_sapp_customer on cdw_sapp_customer.ssn = cdw_sapp_creditcard.cust_ssn " +
            " where cust_zip= '%s' and month= %d and year = %d "+
            " order by day desc ";

    public static final String getTransactionsByTransactionType  = " select count(*) as Number_of_Transactions, sum(transaction_value) as Total_Value "+
            " from cdw_sapp_creditcard "+
            " where transaction_type = '%s' ";

    public static final String getTransactionsByState = " select count(*) as Number_of_Transactions, sum(transaction_value) as Total_value "+
            " from cdw_sapp_creditcard inner join cdw_sapp_branch "+
            " on cdw_sapp_creditcard.branch_code = cdw_sapp_branch.branch_code "+
            " where branch_state = '%s' ";

    public static final String getAccountDetails= "select first_name, middle_name, last_name, credit_card_no, apt_no, street_name, cust_city, cust_state, cust_zip, cust_country, cust_phone, cust_email,ssn from cdw_sapp_customer where ssn =%d ";
    public static final String modifyAccountDetails = " update cdw_sapp_customer "+
            " set apt_no = '%s', street_name = '%s', cust_city = '%s',cust_state = '%s',cust_zip = '%s' where ssn = %d ";
    
    public static final String modifyAccountName = "update cdw_sapp_customer"+
            "set First_name = %s', Middle_name =%s', Last_name =%s' where ssn = %d";
    
    public static final String modifyOtherDetails= " update cdw_sapp_customer " +
    " set cust_phone = %d , cust_email = '%s' " 
   + " where ssn = %d ";

    public static final String getMonthlyBill = " select month, year, sum(transaction_value) as Total_bill, credit_card_no  from cdw_sapp_creditcard "+
            " where credit_card_no = '%s' and month = %d and year = %d group by year, month ";

    public static final String getTransactionsBetweenTwoDates = " select transaction_id,transaction_type, transaction_value, ssn, concat(year, \"-\", LPAD(month,2,'0'), \"-\", LPAD(day,2,'0')) as Dates "
    		+ "from cdw_sapp_creditcard inner join cdw_sapp_customer " +
            " on cdw_sapp_customer.ssn = cdw_sapp_creditcard.cust_ssn "
            + " where ( concat(year, \"-\", LPAD(month,2,'0'), \"-\", LPAD(day,2,'0')) between concat(%d, \"-\", LPAD(%d,2,'0'), \"-\", LPAD(%d,2,'0'))  and concat(%d, \"-\", LPAD(%d,2,'0'), \"-\", LPAD(%d,2,'0')) ) " +
            " and ssn = '%s' " + " order by 5 desc ";
    public static final String checkSSN= " Select * from cdw_sapp_customer where SSN = %d ";

}
