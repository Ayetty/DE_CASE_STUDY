package basic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Validation {

	public  static void main(String []args) {
Scanner sc = new Scanner (System.in);
try {
	Connection con = DriverManager.getConnection("jdbc:mysql://localhost/CDW_SAPP","root","root");
	Statement stmt = con.createStatement();
	System.out.print("SSN:  ");
	String ssn = sc.next ();
	String SQL = "Select * from cdw_sapp_customer where SSN = ' " + ssn + " ' " ;
	ResultSet rs = stmt.executeQuery (SQL);
	if (rs.next())
		System.out.println("SSN Confirmed");
	else
		System.out.println("SSN not found in the database");
}
catch (Exception e) {
	System.out.println("ERROR: " + e.getMessage());
}
	}

}
