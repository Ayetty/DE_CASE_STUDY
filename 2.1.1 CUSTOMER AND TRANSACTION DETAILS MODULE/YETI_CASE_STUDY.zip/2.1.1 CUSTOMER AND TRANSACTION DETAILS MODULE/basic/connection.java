package basic;

import java.sql.*;

public class connection {
    Connection myConn = null;
    Statement myStmt = null;
    ResultSet myRs = null;

    String dbUrl = "jdbc:mysql://localhost:3306/CDW_SAPP?useSSL=false";
    String user = "root";
    String pass = "root";

    public Connection getConnection() throws SQLException{

        myConn = DriverManager.getConnection(dbUrl, user, pass);

        System.out.println("Database connection successful!");

        return myConn;

    }
    public ResultSet executesql(String sql) throws SQLException{

        // getConnection();
        myStmt = myConn.createStatement();

        System.out.println("Processing~~~~~~~~~\n");
        myRs = myStmt.executeQuery(sql);

        return myRs;
        }
    public ResultSet updatesql(String sql,String sql2) throws SQLException{

        myStmt = myConn.createStatement();

        System.out.println(" Update the queries >>>>>>>>\n");
        int Rows = myStmt.executeUpdate(sql);
        ResultSet myRs_2 = myStmt.executeQuery(sql2);

        return myRs_2;
    }
 public void close_connection(Connection myConn, ResultSet myRs)throws SQLException{

            while(myRs.next()){
                if (myConn != null) {
                    myConn.close();
                }
            }
        }
}
