package basic;

@SuppressWarnings("serial")
public class exception extends Exception
{

    public exception(String msg)
    {
        super(msg);
    }

    public exception(String msg, Throwable ex)
    {
        super(msg, ex);
    }

}

