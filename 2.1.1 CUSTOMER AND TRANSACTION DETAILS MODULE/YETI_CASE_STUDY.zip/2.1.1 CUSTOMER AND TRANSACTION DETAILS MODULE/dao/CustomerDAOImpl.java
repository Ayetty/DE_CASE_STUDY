package dao;

import basic.Query;
import basic.connection;
import dao.CustomerDAO;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CustomerDAOImpl implements CustomerDAO
{
    public CustomerDAOImpl() {
        super();

    }
    ResultSet myRs = null;
    connection myConn = null;



    @Override
    public void checkAccount(int ssn) throws SQLException{

        String sql = String.format(Query.getAccountDetails,ssn);
        connection c1 = new connection();
        c1.getConnection();
        c1.executesql(sql);
        ResultSet myRs = c1.executesql(sql);
        Connection myConn = c1.getConnection();
System.out.println("The requested account details is stated below: ");
        while(myRs.next()){
        	System.out.println("Customer Name:     " + myRs.getString("first_name")+ " " +myRs.getString("middle_name")+ " " +  myRs.getString("last_name"));    
            System.out.println("Card Number:          " + myRs.getString("credit_card_no"));    
            System.out.println("Address:                   " +myRs.getString("apt_no")+ " " +myRs.getString("street_name")+ " "+ myRs.getString("cust_city")+ " "+  myRs.getString("cust_state")+ " "+ myRs.getString("cust_zip")+ " "+ myRs.getString("cust_country"));
            System.out.println("Phone Number:        "+myRs.getInt("cust_phone"));
            System.out.println("Email:                        " +myRs.getString("cust_email"));
            }
            c1.close_connection(myConn, myRs);
            
            }

    @Override
    public void modifyAccount(String apt_no,String street_name, String cust_city, String cust_state, String cust_zip, int ssn) throws SQLException{

        String sql_2 = String.format(Query.modifyAccountDetails,apt_no,street_name,cust_city,cust_state,cust_zip,ssn);
        String sql_10 =String.format(Query.checkSSN,ssn);
        connection c2 = new connection();
        Connection myConn_2 = c2.getConnection();
        ResultSet myRs_2  = c2.updatesql(sql_2,sql_10);

        myRs_2.next();
        System.out.println(" Account details modified. Your updated information is  " + myRs_2.getString("apt_no")+ " " + myRs_2.getString("street_name")+ " " +
                    myRs_2.getString("cust_city")+  " " + myRs_2.getString("cust_state") + " " + myRs_2.getString("cust_zip"));
c2.close_connection(myConn_2,myRs_2);
}
    @Override
    public void modifyName(String first_name,String middle_name, String last_name, int ssn) throws SQLException{

        String sql_6 = String.format(Query.modifyAccountName,first_name,middle_name,last_name,ssn);
        String sql_9 =String.format(Query.checkSSN, ssn);
        connection c6 = new connection();
        Connection myConn_6 = c6.getConnection();
        ResultSet myRs_6  = c6.updatesql(sql_6, sql_9);

        myRs_6.next();
        System.out.println(" Account Name Modified. Your updated information is  " + myRs_6.getString("first_name") + " " +
                    myRs_6.getString("middle_name")+ " " +  myRs_6.getString("last_name"));

        c6.close_connection(myConn_6,myRs_6);
    }
    @Override
    public void modifyOtherAccountDetails(int cust_phone,String cust_email, int ssn) throws SQLException{
    	String sql_7 = String.format(Query.modifyOtherDetails,cust_phone,cust_email,ssn);
    	String sql_8 =String.format(Query.checkSSN, ssn);
        connection c7 = new connection();
        Connection myConn_7 = c7.getConnection();
        ResultSet myRs_7  = c7.updatesql(sql_7, sql_8);

        myRs_7.next();
        System.out.println(" Account details modified. Your updated information is  " );
     
      System.out.println(" " + " " + myRs_7.getInt("cust_phone") + " " + myRs_7.getString("cust_email"));
        
        c7.close_connection(myConn_7,myRs_7);
    }
    @Override
    public void getMonthlyBill(String credit_card_no, int month, int year) throws SQLException {

        String sql_3 = String.format(Query.getMonthlyBill,credit_card_no,month,year);
        connection c3 = new connection();

        Connection myConn_3 = c3.getConnection();
        ResultSet myRs_3 = c3.executesql(sql_3);


        System.out.println("The requested monthly bill is :  " + "Month" + " " + "Year" +" " + "Credit_card_no"+ "    "+"Total_bill");
        while(myRs_3.next()){
            System.out.println("                                                " +
                    " " + myRs_3.getInt("month") + "    " +
                    myRs_3.getInt("year")+ "  "+ myRs_3.getString("credit_card_no")+ "  "+
                    myRs_3.getBigDecimal("Total_bill"));
        }
        c3.close_connection(myConn_3, myRs_3);

}

        @Override
        public void  checkTransactionsBetweenDates(int year1, int month1, int day1, int year2, int month2, int day2, int ssn) throws SQLException{

            String sql_4 = String.format(Query.getTransactionsBetweenTwoDates,year1, month1,day1,year2, month2,day2,ssn);
            connection c4 = new connection();

            Connection myConn_4 = c4.getConnection();
            ResultSet myRs_4 = c4.executesql(sql_4);

            System.out.println("the transaction detail is: ");
            while(myRs_4.next()){
                System.out.println("                           " +  myRs_4.getInt("transaction_id")+ " "+ myRs_4.getString("Transaction_type")+ " " + myRs_4.getBigDecimal("transaction_value") + " " +
                    myRs_4.getDate("dates"));
                }

        c4.close_connection(myConn_4, myRs_4);
        }
        
        public ResultSet  checkSSN(int ssn) throws SQLException {
        	
        	String sql_5 = String.format(Query.checkSSN, ssn);
        	 connection c5 = new connection();
        	 Connection myConn_5 = c5.getConnection();
             myRs = c5.executesql(sql_5);
            
             return myRs;
             
        }
        

    }



