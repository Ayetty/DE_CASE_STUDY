package dao;

import java.sql.SQLException;

public interface TransactionDAO {

    public void getTransactionsByZipcode(String Zip_code, int month, int year) throws SQLException;
    public void TotalTransactionNumberAndValue(String transaction_type) throws SQLException;
    public void getTransactionByState( String state) throws SQLException;

}
