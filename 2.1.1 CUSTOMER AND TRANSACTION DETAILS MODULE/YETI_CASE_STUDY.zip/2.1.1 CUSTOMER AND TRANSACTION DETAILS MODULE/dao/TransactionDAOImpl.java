 package dao;
import basic.Query;

import java.sql.Connection;
import java.sql.DriverManager;
import basic.connection;
import dao.TransactionDAO;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TransactionDAOImpl implements TransactionDAO {

    public TransactionDAOImpl() {
        super();

    }

    @Override
    public void getTransactionsByZipcode(String Zip_code, int month, int year) throws SQLException {

        String sql = String.format(Query.getTransactionsByZipCode, Zip_code, month, year);

        connection t1 = new connection();

        Connection myConn = t1.getConnection();
        ResultSet myRs = t1.executesql(sql);

        while (myRs.next()) {
            System.out.println("             " + myRs.getString("first_name") + " " +
                    myRs.getString("middle_name") + " " + myRs.getString("last_name") + " " +
                    myRs.getString("cust_zip") + " " + myRs.getTimestamp("last_updated") + " " +
                    myRs.getInt("transaction_id") + " " + myRs.getInt("day") + " " + myRs.getInt("month") + " " +
                    myRs.getInt("year") + " " + myRs.getString("credit_card_no") + " " + myRs.getInt("branch_code") + " " +
                    myRs.getString("Transaction_type") + " " + myRs.getBigDecimal("transaction_value"));

        }

        t1.close_connection(myConn, myRs);


    }

    @Override
    public void TotalTransactionNumberAndValue(String transaction_type) throws SQLException {

        String sql2 = String.format(Query.getTransactionsByTransactionType, transaction_type);

        connection t2 = new connection();

        Connection myConn2 = t2.getConnection();
        ResultSet myRs2 = t2.executesql(sql2);

        System.out.println("The total transactions are : Number Total_Value");
        while (myRs2.next()) {
            System.out.println("                                            " + myRs2.getString("Number_of_Transactions") + "         " +
                    myRs2.getInt("Total_Value"));

        }
        t2.close_connection(myConn2, myRs2);
    }

    @Override
    public void getTransactionByState(String state) throws SQLException {

        String sql3 = String.format(Query.getTransactionsByState, state);

        connection t3 = new connection();

        Connection myConn3 = t3.getConnection();
        ResultSet myRs3 = t3.executesql(sql3);

        System.out.println("The result is : Number Total_Value");
        while (myRs3.next()) {
            System.out.println("                         " + myRs3.getString("Number_of_Transactions") + "    " +
                    myRs3.getInt("Total_Value"));

        }
        t3.close_connection(myConn3, myRs3);
    }
}
